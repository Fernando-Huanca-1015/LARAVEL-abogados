const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason
} = require('@whiskeysockets/baileys');

const qrcode = require('qrcode-terminal');
const fs = require("fs");
const axios = require("axios");
const P = require("pino");

const rutaEstados = './estadoUsuarios.json';
if (!fs.existsSync(rutaEstados)) fs.writeFileSync(rutaEstados, '{}');
let estados = JSON.parse(fs.readFileSync(rutaEstados));


function extraerTexto(msg) {
    if (!msg || !msg.message) return '';
    const m = msg.message;
    const contenido = m.ephemeralMessage?.message || m;
    return contenido.conversation || contenido.extendedTextMessage?.text || contenido.imageMessage?.caption || contenido.videoMessage?.caption || contenido.buttonsResponseMessage?.selectedButtonId || contenido.listResponseMessage?.singleSelectReply?.selectedRowId || '';
}


async function guardarDatos(nombre, ciudad, edad, telefono, email, especialidad, mensaje, consulta) {
    try {
        const payload = { nombre, ciudad, edad, telefono, email, especialidad, mensaje, consulta };
        console.log("📦 Enviando a Laravel:", payload);

        const res = await axios.post('http://127.0.0.1:8000/api/consultas', payload, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });

        console.log('✅ Laravel respondió:', res.data);
        return true;
    } catch (error) {
        console.error('❌ Laravel respondió con error:', error.response?.data || error.message);
        return false;
    }
}

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const sock = makeWASocket({ auth: state, logger: P({ level: 'silent' }) });

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect, qr } = update;
        if (qr) qrcode.generate(qr, { small: false });
        if (connection === 'close') startBot();
        if (connection === 'open') console.log('✅ Conectado correctamente a WhatsApp');
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message || msg.key.fromMe) return;

        const remoteJid = msg.key.remoteJid;
        const texto = extraerTexto(msg).trim();
        const telefonoWa = remoteJid.replace(/@s\.whatsapp\.net$/, '');

        if (!estados[remoteJid]) {
            estados[remoteJid] = { paso: 1 };
            await sock.sendMessage(remoteJid, {
                text: `👋 *Bienvenido a SELEGAL - Servicios Legales, Asesores y Consultores*\n\n📚 *Materias conciliables:*\n👶 Pensión de alimentos\n👨‍👩‍👧 Régimen de visitas\n🧒 Tenencia de hijos\n💰 Liquidación de sociedad de gananciales\n🏠 División y partición de bienes\n🚪 Desalojo / Reivindicación\n📄 Incumplimiento de contrato\n⚖️ Otros derechos de libre disposición\n\nPor favor, indícame tu *nombre completo*:`
            });
        } else {
            const user = estados[remoteJid];

            try {
                switch (user.paso) {
                    case 1:
                        user.nombre = texto;
                        user.paso = 2;
                        await sock.sendMessage(remoteJid, { text: "🌆 ¿De qué *ciudad* eres?" });
                        break;

                    case 2:
                        user.ciudad = texto;
                        user.paso = 3;
                        await sock.sendMessage(remoteJid, { text: "📅 ¿Cuál es tu *edad*?" });
                        break;

                    case 3:
                        user.edad = texto;
                        user.paso = 4;
                        await sock.sendMessage(remoteJid, {
                            text: "📞 ¿Cuál es tu *teléfono*? (9 dígitos sin +51, o deja vacío para usar tu número de WhatsApp)"
                        });
                        break;

                    case 4:
                        if (texto !== '' && !/^[0-9]{9}$/.test(texto)) {
                            await sock.sendMessage(remoteJid, {
                                text: "❗ El número debe tener exactamente 9 dígitos. Intenta nuevamente."
                            });
                            return;
                        }
                        user.telefono = texto === '' ? telefonoWa.slice(-9) : texto;
                        user.paso = 5;
                        await sock.sendMessage(remoteJid, { text: "📧 ¿Cuál es tu *correo electrónico*?" });
                        break;

                    case 5:
                        user.email = texto;
                        user.paso = 6;
                        await sock.sendMessage(remoteJid, { text: "📚 ¿Cuál es la *especialidad legal* que buscas? (ej: pensión, tenencia, contrato...)" });
                        break;

                    case 6:
                        user.especialidad = texto;
                        user.paso = 7;
                        await sock.sendMessage(remoteJid, { text: "💬 ¿Deseas agregar algún *mensaje adicional*?" });
                        break;

                    case 7:
                        user.mensaje = texto;
                        user.paso = 8;
                        await sock.sendMessage(remoteJid, { text: "📝 Por favor, describe tu *consulta legal* en detalle:" });
                        break;

                    case 8:
                        user.consulta = texto;
                        user.paso = 9;

                        const resumen = `🧾 *Resumen de tus datos:*\n\n👤 Nombre: ${user.nombre}\n🌆 Ciudad: ${user.ciudad}\n📅 Edad: ${user.edad}\n📞 Teléfono: ${user.telefono}\n📧 Email: ${user.email}\n📚 Especialidad: ${user.especialidad}\n💬 Mensaje: ${user.mensaje}\n📄 Consulta: ${user.consulta}\n\n¿Están correctos tus datos? (responde "sí" o el *campo* que deseas corregir)`;
                        await sock.sendMessage(remoteJid, { text: resumen });
                        break;

                    case 9:
                        if (texto.toLowerCase() === 'sí' || texto.toLowerCase() === 'si') {
                            const { nombre, ciudad, edad, telefono, email, especialidad, mensaje, consulta } = user;
                            const exito = await guardarDatos(nombre, ciudad, edad, telefono, email, especialidad, mensaje, consulta);
                            await sock.sendMessage(remoteJid, {
                                text: exito
                                    ? `✅ ¡Gracias ${nombre}! Hemos guardado tu consulta legal. Un asesor se comunicará contigo pronto.`
                                    : "❌ Ocurrió un error al guardar tus datos. Intenta más tarde."
                            });
                            delete estados[remoteJid];
                        } else {
                            const campo = texto.toLowerCase();
                            const camposValidos = ['nombre', 'ciudad', 'edad', 'telefono', 'teléfono', 'email', 'especialidad', 'mensaje', 'consulta'];
                            if (camposValidos.includes(campo)) {
                                estados[remoteJid].campoEdicion = campo;
                                estados[remoteJid].paso = 10;
                                await sock.sendMessage(remoteJid, {
                                    text: `✏️ Escribe el nuevo valor para *${campo}*:`
                                });
                            } else {
                                await sock.sendMessage(remoteJid, {
                                    text: "❗ Responde con 'sí' o indica el *campo* que deseas cambiar (nombre, ciudad, edad, teléfono, email, especialidad, mensaje, consulta)."
                                });
                            }
                        }
                        break;

                    case 10:
                        const campoCambiar = estados[remoteJid].campoEdicion;
                        estados[remoteJid][campoCambiar] = texto;
                        estados[remoteJid].paso = 9;

                        const r = estados[remoteJid];
                        const resumenNuevo = `🧾 *Resumen actualizado:*\n\n👤 Nombre: ${r.nombre}\n🌆 Ciudad: ${r.ciudad}\n📅 Edad: ${r.edad}\n📞 Teléfono: ${r.telefono}\n📧 Email: ${r.email}\n📚 Especialidad: ${r.especialidad}\n💬 Mensaje: ${r.mensaje}\n📄 Consulta: ${r.consulta}\n\n¿Están correctos tus datos? (responde "sí" o el *campo* que deseas corregir)`;
                        await sock.sendMessage(remoteJid, { text: resumenNuevo });
                        break;
                }

                fs.writeFileSync(rutaEstados, JSON.stringify(estados, null, 2));
            } catch (error) {
                console.error("❌ Error:", error);
                await sock.sendMessage(remoteJid, {
                    text: "⚠️ Ocurrió un error inesperado. Intenta más tarde."
                });
                delete estados[remoteJid];
                fs.writeFileSync(rutaEstados, JSON.stringify(estados, null, 2));
            }
        }
    });
}

startBot();

