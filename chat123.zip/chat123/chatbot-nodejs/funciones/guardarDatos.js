const axios = require('axios');

async function guardarDatos(nombre, ciudad, edad, telefono, email, especialidad, mensaje, consulta) {
    try {
        const payload = { nombre, ciudad, edad, telefono, email, especialidad, mensaje, consulta };
        console.log("📦 Enviando a Laravel:", payload);

        const res = await axios.post('http://127.0.0.1:8000/api/consultas', payload, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });

        console.log('✅ Laravel respondió:', res.data);
        return true;
    } catch (error) {
        console.error('❌ Laravel respondió con error:', error.response?.data || error.message);
        return false;
    }
}

module.exports = guardarDatos;
